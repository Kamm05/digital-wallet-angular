const someTest = 'This is some Test';

/**
 * Display some test
 * @returns {string}
 */
 function display() {
    return someTest;
  }

  module.exports = {
    display
  };
