/*
 * Public API Surface of ui-payments
 */

export * from './lib/ui-payments.component';
export * from './lib/ui-payments.module';
