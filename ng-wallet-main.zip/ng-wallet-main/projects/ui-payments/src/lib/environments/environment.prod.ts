export const environment = {
  production: true,
  title: 'Production Environment',
  apiURL: 'https://api.nosher.app/',
  maxFileSize: 30
};
