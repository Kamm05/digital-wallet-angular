export class DisplayItem {

  label!:          string;
  price!:          string;
}
