export class Tax {

  label!:   string;
  amount!:  string;
}
