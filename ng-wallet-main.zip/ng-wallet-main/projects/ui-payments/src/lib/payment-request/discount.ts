export class Discount {

  label!:   string;
  amount!:  string;
}
