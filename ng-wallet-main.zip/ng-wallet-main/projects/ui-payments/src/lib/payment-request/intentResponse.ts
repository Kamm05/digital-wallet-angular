export class IntentResponse {
    id?: string;
    status?: string;
//    stripeId?: string;
    client_secret?: number;
    reference?: string;
}
