export class Item {

  label!:        string;
  price!:       any;
  quantity!:    number;
}
